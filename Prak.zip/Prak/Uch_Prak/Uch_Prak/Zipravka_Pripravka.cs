using System;
using System.Collections.Generic;

namespace GasStation
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "АЗС 'ЗАПРАВКА'";
            Console.WriteLine("=== АЗС 'ЗАПРАВКА' ===\n");
            new StationMenu().ShowMainMenu();
            Console.WriteLine("\nСпасибо, что выбрали нашу АЗС!");
            Console.ReadKey();
        }
    }

    public class StationMenu
    {
        private StationManager manager = new StationManager();

        public StationMenu()
        {
            var f1 = new Fuel(1, "АИ-92", 52.50m, "Бензин");
            var f2 = new Fuel(2, "АИ-95", 55.20m, "Бензин");
            var f3 = new Fuel(3, "Дизель", 53.80m, "Дизель");
            var f4 = new Fuel(4, "АИ-100", 58.90m, "Бензин");
            var f5 = new Fuel(5, "Газ", 28.50m, "Газ");

            foreach (var f in new[] { f1, f2, f3, f4, f5 }) manager.AddFuel(f);

            var p1 = new FuelPump { Id = 1, FuelType = f1, MaxCapacity = 1000 };
            var p2 = new FuelPump { Id = 2, FuelType = f2, MaxCapacity = 1000 };
            var p3 = new FuelPump { Id = 3, FuelType = f3, MaxCapacity = 1000 };
            var p4 = new FuelPump { Id = 4, FuelType = f4, MaxCapacity = 800 };
            var p5 = new FuelPump { Id = 5, FuelType = f5, MaxCapacity = 600 };

            p1.Refill(850); p2.Refill(920); p3.Refill(780); p4.Refill(650); p5.Refill(500);
            foreach (var p in new[] { p1, p2, p3, p4, p5 }) manager.AddFuelPump(p);

            manager.RegisterCustomer("Иван Петров", "А123БВ", 1500);
            manager.RegisterCustomer("Петр Иванов", "В456ГД", 3000);
            manager.RegisterCustomer("Сергей Сидоров", "Е789ЖЗ", 500);
        }

        public void ShowAvailableFuels()
        {
            Console.WriteLine("\n--- ДОСТУПНОЕ ТОПЛИВО ---");
            Console.WriteLine("ID  Название    Цена     Тип");
            foreach (var f in manager.GetAllFuels())
                Console.WriteLine($"{f.Id,-3} {f.Name,-11} {f.PricePerLiter,6:F2} {f.FuelType}");
        }

        public void ProcessRefueling()
        {
            Console.WriteLine("\n--- ЗАПРАВКА ---");
            Console.Write("Номер авто: ");
            string num = Console.ReadLine().Trim().ToUpper();
            if (string.IsNullOrEmpty(num)) { Console.WriteLine("Ошибка!"); return; }

            Customer c = manager.FindCustomerByCarNumber(num);
            if (c == null)
            {
                Console.WriteLine("Новый клиент.");
                Console.Write("Имя: ");
                string name = Console.ReadLine().Trim();
                if (string.IsNullOrEmpty(name)) name = "Клиент";
                Console.Write("Баланс: ");
                if (!decimal.TryParse(Console.ReadLine(), out decimal b) || b < 0) b = 0;
                c = manager.RegisterCustomer(name, num, b);
                Console.WriteLine($"ID: {c.Id}");
            }
            Console.WriteLine($"{c.Name} | Баланс: {c.Balance:F2}");

            ShowAvailableFuels();
            Console.Write("ID топлива: ");
            if (!int.TryParse(Console.ReadLine(), out int fid)) return;
            Fuel fuel = manager.GetAllFuels().Find(f => f.Id == fid);
            if (fuel == null) return;

            var pumps = manager.GetAllPumps().FindAll(p => p.FuelType.Id == fid && p.CurrentFuel > 0);
            if (pumps.Count == 0) { Console.WriteLine("Нет топлива"); return; }

            Console.WriteLine("Колонки:");
            foreach (var p in pumps) Console.WriteLine($"#{p.Id} - {p.CurrentFuel:F2}л");
            Console.Write("Номер колонки: ");
            if (!int.TryParse(Console.ReadLine(), out int pid)) return;
            FuelPump pump = pumps.Find(p => p.Id == pid);
            if (pump == null) return;

            Console.Write("Литры (0 - отмена): ");
            if (!decimal.TryParse(Console.ReadLine(), out decimal liters) || liters <= 0) return;

            if (!pump.HasEnoughFuel(liters))
            {
                Console.Write($"Доступно {pump.CurrentFuel:F2}л. Заправить? (д/н): ");
                if (Console.ReadLine().Trim().ToLower() == "д") liters = pump.CurrentFuel;
                else return;
            }

            decimal cost = fuel.CalculateCost(liters);
            if (!c.PayForRefueling(cost))
            {
                Console.WriteLine($"Нужно {cost:F2}, есть {c.Balance:F2}");
                return;
            }

            decimal actual = pump.Refuel(liters);
            c.AddToHistory(fuel, actual, cost);
            manager.RecordSale(cost);

            Console.WriteLine($"Заправлено: {actual:F2}л, Сумма: {cost:F2}руб, Баланс: {c.Balance:F2}руб");
        }

        public void ShowStationStats()
        {
            Console.WriteLine("\n--- СТАТИСТИКА ---");
            Console.WriteLine($"Выручка: {manager.GetTotalRevenue():F2}руб");
            Console.WriteLine($"Клиентов: {manager.GetCustomerCount()}");
            Console.WriteLine("\nКолонки:");
            foreach (var p in manager.GetAllPumps()) p.ShowPumpInfo();
        }

        public void TopUpBalanceMenu(Customer customer = null)
        {
            Console.WriteLine("\n--- ПОПОЛНЕНИЕ ---");
            if (customer == null)
            {
                Console.Write("Номер авто: ");
                customer = manager.FindCustomerByCarNumber(Console.ReadLine().Trim().ToUpper());
                if (customer == null) { Console.WriteLine("Не найден"); return; }
            }
            Console.Write("Сумма: ");
            if (decimal.TryParse(Console.ReadLine(), out decimal a) && a > 0)
                customer.TopUpBalance(a);
        }

        public void ShowCustomerHistory()
        {
            Console.WriteLine("\n--- ИСТОРИЯ ---");
            Console.Write("Номер авто: ");
            Customer c = manager.FindCustomerByCarNumber(Console.ReadLine().Trim().ToUpper());
            if (c == null) Console.WriteLine("Не найден");
            else c.ShowHistory();
        }

        public void RefillPumpMenu()
        {
            Console.WriteLine("\n--- ПОПОЛНЕНИЕ КОЛОНКИ ---");
            foreach (var p in manager.GetAllPumps()) p.ShowPumpInfo();
            Console.Write("Номер колонки: ");
            if (!int.TryParse(Console.ReadLine(), out int id)) return;
            FuelPump p2 = manager.GetAllPumps().Find(p => p.Id == id);
            if (p2 == null) return;
            Console.Write("Литры: ");
            if (decimal.TryParse(Console.ReadLine(), out decimal l) && l > 0)
                p2.Refill(l);
        }

        public void ShowMainMenu()
        {
            bool run = true;
            while (run)
            {
                Console.Clear();
                Console.WriteLine("=== АЗС 'ЗАПРАВКА' ===");
                Console.WriteLine("1. Цены\n2. Заправить\n3. Статистика\n4. Пополнить баланс\n5. История\n6. Пополнить колонку\n7. Выход");
                Console.Write("Выбор: ");
                switch (Console.ReadLine())
                {
                    case "1": ShowAvailableFuels(); break;
                    case "2": ProcessRefueling(); break;
                    case "3": ShowStationStats(); break;
                    case "4": TopUpBalanceMenu(null); break;
                    case "5": ShowCustomerHistory(); break;
                    case "6": RefillPumpMenu(); break;
                    case "7": run = false; break;
                    default: Console.WriteLine("Ошибка"); break;
                }
                if (run) { Console.WriteLine("\nEnter..."); Console.ReadLine(); }
            }
        }
    }

    public class StationManager
    {
        private List<Customer> customers = new List<Customer>();
        private List<FuelPump> pumps = new List<FuelPump>();
        private List<Fuel> fuels = new List<Fuel>();
        private Dictionary<string, (decimal Liters, decimal Revenue)> sales = new Dictionary<string, (decimal, decimal)>();
        private int nextId = 1;
        private decimal revenue = 0;

        public Customer RegisterCustomer(string name, string car, decimal balance)
        {
            var c = new Customer { Id = nextId++, Name = name, CarNumber = car.ToUpper() };
            c.TopUpBalance(balance);
            customers.Add(c);
            return c;
        }
        public Customer FindCustomerByCarNumber(string car) => customers.Find(c => c.CarNumber.Equals(car, StringComparison.OrdinalIgnoreCase));
        public void RecordSale(decimal amount) => revenue += amount;
        public void AddFuelPump(FuelPump p) => pumps.Add(p);
        public void AddFuel(Fuel f) => fuels.Add(f);
        public List<Fuel> GetAllFuels() => fuels;
        public List<FuelPump> GetAllPumps() => pumps;
        public decimal GetTotalRevenue() => revenue;
        public int GetCustomerCount() => customers.Count;
        public Dictionary<string, (decimal Liters, decimal Revenue)> GetSalesByFuelType() => sales;
        public List<Customer> GetTopCustomers(int count)
        {
            customers.Sort((a, b) => b.GetTotalSpent().CompareTo(a.GetTotalSpent()));
            return customers.GetRange(0, Math.Min(count, customers.Count));
        }
    }

    public class FuelPump
    {
        public int Id { get; set; }
        public Fuel FuelType { get; set; }
        public decimal CurrentFuel { get; private set; }
        public decimal MaxCapacity { get; set; } = 1000;
        public decimal Refuel(decimal l)
        {
            decimal a = HasEnoughFuel(l) ? l : CurrentFuel;
            CurrentFuel -= a;
            return a;
        }
        public bool HasEnoughFuel(decimal l) => CurrentFuel >= l;
        public void Refill(decimal l) => CurrentFuel = Math.Min(CurrentFuel + l, MaxCapacity);
        public void ShowPumpInfo()
        {
            double p = (double)(CurrentFuel / MaxCapacity) * 100;
            Console.WriteLine($"#{Id} {FuelType.Name}: {CurrentFuel,5:F1}/{MaxCapacity}л ({p:F0}%)");
        }
    }

    public class Fuel
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public decimal PricePerLiter { get; set; }
        public string FuelType { get; set; }
        public Fuel(int id, string name, decimal price, string type)
        {
            Id = id; Name = name; PricePerLiter = price < 0 ? 0.01m : price; FuelType = type;
        }
        public override string ToString() => $"{Name} - {PricePerLiter:F2} руб/л ({FuelType})";
        public decimal CalculateCost(decimal l) => PricePerLiter * l;
    }

    public class Customer
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string CarNumber { get; set; }
        public decimal Balance { get; private set; }
        private List<RefuelingRecord> history = new List<RefuelingRecord>();
        public class RefuelingRecord
        {
            public DateTime Date { get; set; }
            public Fuel FuelType { get; set; }
            public decimal Liters { get; set; }
            public decimal Cost { get; set; }
        }
        public void TopUpBalance(decimal a)
        {
            if (a <= 0) return;
            Balance += a;
            Console.WriteLine($"Баланс: {Balance:F2}руб");
        }
        public bool PayForRefueling(decimal cost)
        {
            if (cost <= 0 || Balance < cost) return false;
            Balance -= cost;
            return true;
        }
        public void AddToHistory(Fuel f, decimal l, decimal c) =>
            history.Add(new RefuelingRecord { Date = DateTime.Now, FuelType = f, Liters = l, Cost = c });
        public decimal GetTotalSpent()
        {
            decimal t = 0;
            foreach (var h in history) t += h.Cost;
            return t;
        }
        public void ShowHistory()
        {
            Console.WriteLine($"\n{Name} {CarNumber}");
            if (history.Count == 0) { Console.WriteLine("Нет заправок"); return; }
            decimal tl = 0, tc = 0;
            foreach (var h in history)
            {
                Console.WriteLine($"{h.Date:dd.MM.yy} {h.FuelType.Name,-6} {h.Liters,5:F1}л = {h.Cost,6:F2}руб");
                tl += h.Liters; tc += h.Cost;
            }
            Console.WriteLine($"Итого: {tl:F1}л, {tc:F2}руб");
        }
        public void ShowCustomerInfo() =>
            Console.WriteLine($"{Name} | {CarNumber} | Баланс: {Balance:F2}руб | Заправок: {history.Count}");
    }
}